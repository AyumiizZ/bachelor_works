# redditMockup
Created a very simple mockup of reddit.com homepage using HTML/CSS and JavaScript
